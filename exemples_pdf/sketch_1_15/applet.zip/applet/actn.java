
public abstract class actn {
  public abstract void a();
}
