import processing.core.*; 
import processing.xml.*; 

import gifAnimation.*; 
import processing.opengl.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Livredor_v0_4 extends PApplet {

//GIF STUFF


// GIF variables
GifMaker gifExport;
//PImage logo;
//float rotation = 0.0;
// animation variables
String buff = "        ";
boolean didntTypeYet = true;
int i =0;
int borderh =100;
int borderv =100;
boolean doyouloop =false;
//popupmenu stuff
final String ss="  ";
int mill;
String s=ss;
boolean startRec;
boolean stopRec;
boolean saveGif;


public void setup() {
  size(400, 300);
  background(255);
  colorMode(HSB);
  smooth();
  frameRate(12);
  //FONTS
  textFont(loadFont("Mosaicleaf-48.vlw"), 48);
  // GIFS  
  println("gifAnimation " + Gif.version());
  gifExport = new GifMaker(this, "export"+year() + nf(month(),2) + nf(day(),2) + "-"  + nf(hour(),2) + nf(minute(),2) + nf(second(),2)+".gif");
  gifExport.setRepeat(0); // make it an "endless" animation
  gifExport.setTransparent(0, 0, 0); // make black the transparent color. every black pixel in the animation will be transparent
  // GIF doesn't know have alpha values like processing. a pixel can only be totally transparent or totally opaque.
  // set the processing background and the transparent gif color to the same value as the gifs destination background color 
  // (e.g. the website bg-color). Like this you can have the antialiasing from processing in the gif.
}

public void draw() { 

  //ANIMATION
  //fadeout effcect
  fill (255, 100);
  rect (0, 0, width, height);
  // instructions
  if (didntTypeYet) {
    fill(0);
    //text("Use the keyboard.", 22, 40);
  }
  // place letter from buffer in a variable
  char k;
  k = buff.charAt(buff.length()-1-i);
  // parameters
  fill(random(255), 255, 255);
  textSize(random(48, 100));
  // display letter
  translate(width/2, height/2);
  text(k, random(-width/2, width/2), random(-height/2, height/2));
  resetMatrix();
  //next letter please
  i++;
  // reset counter to loop through the buffer
  if (i==buff.length()) {
    i=0;
  }
  // record the gif with key interaction (enter)
  if ( startRec == true) {
    gifExport.setDelay(150);
    gifExport.addFrame();
  } 
  // export it with key interaction (echap)
  else if (saveGif == true) {
    gifExport.finish();
  }
}




public void keyPressed() {
  //prevent escaping and save
  if (key == ESC) {
    saveGif=true;
    startRec=false;
    key=0;
  }
  
  if (key == ENTER){
    startRec=true;
  }
  // do stuff like put the key stroked in a buffer and avoid trapholes
  char k;
  k = (char)key;
  println(key);  
  switch(k) {
  case 8:
    if (buff.length()>0) {
      buff = buff.substring(1);
    }
    break;
  case 13:  // Avoid special keys
  case 10:
  case 65535:
  case 127:
  case 27:
    break;
  default:
    didntTypeYet = false;
    buff=k+buff;
    break;
  }
}
public void mouseClicked() {
  mill=millis();
  if (mouseButton==RIGHT) popupMenu();
}

public void popupMenu() {
  fill(255);
  SMenu p=new SMenu(this, mouseX, mouseY);
  p.SMSubM("Aide                             ");
  p.SMItem("1-Choisissez votre police de caract\u00e8re", new actn() {
    public void a() {
    }
  }
  ); // or call proc
  p.SMItem("2-Tapez votre message", new actn() {
    public void a() {
    }
  }
  ); // or call proc
  p.SMItem("3-Appuyez sur entrer pour d\u00e9marrer l'enregistrement ", new actn() {
    public void a() {
    }
  }
  ); // or call proc
  p.SMItem("4-Appuyez sur echap pour sauvegarder le gif anim\u00e9 ", new actn() {
    public void a() {
    }
  }
  ); // or call proc
  p.SMEnd();
  p.SMSubM("Police de caract\u00e8res");
  p.SMItem("Mosaic Leaf", new actn() {
    public void a() {
      textFont(loadFont("Mosaicleaf-48.vlw"), 48);
    }
  }
  ); 
  p.SMItem("Bauhaus", new actn() {
    public void a() {
      textFont(loadFont("Bauhaus93-48.vlw"), 48);
    }
  }
  );
  p.SMItem("Harlow", new actn() {
    public void a() {
      textFont(loadFont("HarlowSolid-48.vlw"), 48);
    }
  }
  );
  p.SMItem("Magneto", new actn() {
    public void a() {
      textFont(loadFont("Magneto-Bold-48.vlw"), 48);
    }
  }
  );
  p.SMEnd();

  p.SMItem("R\u00e9initialiser", new actn() {
    public void a() {
      buff = "                                           ";
    }
  }
  );
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "Livredor_v0_4" });
  }
}
